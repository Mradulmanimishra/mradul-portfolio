import React, { useRef, useMemo, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';

// 1. The Interactive & Audio-Reactive Particle System
const PortfolioParticles = () => {
  const pointsRef = useRef<THREE.Points>(null);
  const { mouse } = useThree(); // For mouse tracking
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [dataArray, setDataArray] = useState<Uint8Array | null>(null);

  // Initialize Web Audio API for microphone input
  useEffect(() => {
    const initAudio = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = audioContext.createMediaStreamSource(stream);
        
        const analyserNode = audioContext.createAnalyser();
        analyserNode.fftSize = 256; 
        source.connect(analyserNode);
        
        const data = new Uint8Array(analyserNode.frequencyBinCount);
        
        setAnalyser(analyserNode);
        setDataArray(data);
      } catch (err) {
        console.log("Audio reactivity disabled: Microphone access denied.");
      }
    };

    initAudio();

    return () => {
      if (analyser && analyser.context.state !== 'closed') {
        (analyser.context as AudioContext).close();
      }
    };
  }, []);

  // Generate the 3D Sphere Geometry
  const count = 6000;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 2.0;
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi);
    }
    return pos;
  }, []);

  // Frame-by-frame Animation Loop
  useFrame(() => {
    if (!pointsRef.current) return;

    // A. Constant base rotation
    pointsRef.current.rotation.y += 0.002;

    // B. Mouse interaction (Smooth Tilt)
    const targetX = mouse.x * 0.5; 
    const targetY = -mouse.y * 0.5;
    pointsRef.current.rotation.x = THREE.MathUtils.lerp(pointsRef.current.rotation.x, targetY, 0.1);
    pointsRef.current.rotation.y = THREE.MathUtils.lerp(pointsRef.current.rotation.y, targetX, 0.1);

    // C. Audio Reactivity (Pulsing Scale)
    if (analyser && dataArray) {
      analyser.getByteFrequencyData(dataArray);
      
      // Isolate lower frequencies (bass/heavy tones)
      let bassSum = 0;
      for (let i = 0; i < 10; i++) {
        bassSum += dataArray[i];
      }
      const averageBass = bassSum / 10;

      // Map audio volume to a 3D scale multiplier
      const targetScale = 1.0 + (averageBass / 255) * 0.4;

      // Smoothly interpolate the scale to prevent jittering
      pointsRef.current.scale.x = THREE.MathUtils.lerp(pointsRef.current.scale.x, targetScale, 0.15);
      pointsRef.current.scale.y = THREE.MathUtils.lerp(pointsRef.current.scale.y, targetScale, 0.15);
      pointsRef.current.scale.z = THREE.MathUtils.lerp(pointsRef.current.scale.z, targetScale, 0.15);
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial
        size={0.012}
        color="#ff0000" /* Swapped to striking Portfolio Red */
        transparent
        opacity={0.8}
        sizeAttenuation={true}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

// 2. The Main Hero Layout Overlay
export const Hero = () => {
  return (
    <section id="hero" className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-[#050505]">
      {/* 3D Background Canvas */}
      <div className="absolute inset-0 z-0 opacity-60">
        <Canvas 
          camera={{ position: [0, 0, 6] }}
          gl={{ 
            powerPreference: "high-performance",
            alpha: true,
            antialias: true,
            preserveDrawingBuffer: true
          }}
          onCreated={({ gl }) => {
            gl.domElement.addEventListener('webglcontextlost', (event) => {
              event.preventDefault();
              console.warn('WebGL context lost. Attempting to restore...');
            }, false);
          }}
        >
          <PortfolioParticles />
        </Canvas>
      </div>

      {/* Your Portfolio UI Overlay */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-8">
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-white text-[clamp(3.5rem,10vw,7rem)] leading-[1.1] font-extrabold mb-8 uppercase"
        >
          Building Scalable AI Solutions <br/> & Patented Systems
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-text-secondary font-sans text-lg md:text-xl max-w-2xl mb-10 leading-relaxed"
        >
          Discover the power of innovation and embrace growth with bold strategies backed by machine learning, data pipelines, and patented systems.
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="flex flex-col items-center gap-8"
        >
          <a 
            href="#contact"
            className="group relative inline-flex items-center gap-4 bg-accent text-white font-display text-xl px-10 py-5 rounded-sm hover:translate-y-[-4px] transition-all red-glow"
          >
            GET IN TOUCH
            <span className="group-hover:translate-x-2 transition-transform">→</span>
          </a>

          {/* Dynamic Skills Tag Cloud/Scroll */}
          <div className="flex flex-wrap justify-center gap-4 max-w-xl">
            {['Python', 'SQL', 'NoSQL', 'TensorFlow', 'Keras'].map((skill, i) => (
              <motion.span
                key={skill}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1 + (i * 0.1), duration: 0.5 }}
                className="px-4 py-1 border border-accent/30 text-accent font-mono text-xs tracking-widest uppercase rounded-full hover:bg-accent hover:text-white transition-colors cursor-default"
              >
                {skill}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10"
      >
        <span className="text-text-muted font-display text-xs tracking-widest">SCROLL FOR MORE</span>
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <ChevronDown className="text-accent" />
        </motion.div>
      </motion.div>
    </section>
  );
};
