import React from 'react';
import { motion } from 'motion/react';

const skillGroups = [
  {
    category: 'LANGUAGES',
    skills: ['Python', 'SQL', 'NoSQL', 'Shell Scripting']
  },
  {
    category: 'AI / MACHINE LEARNING',
    skills: ['TensorFlow', 'Keras', 'Scikit-learn', 'NLTK', 'Spacy']
  },
  {
    category: 'VISUALIZATION',
    skills: ['Tableau', 'Power BI', 'React Dashboards', 'D3.js']
  },
  {
    category: 'DEVOPS & TOOLS',
    skills: ['Docker', 'Kubernetes', 'Git', 'AWS', 'CI/CD']
  }
];

export const Skills = () => {
  return (
    <section id="skills" className="w-full py-20 px-8">
      <div className="max-w-[1400px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-white text-6xl mb-16"
        >
          TECHNICAL EXPERTISE
        </motion.h2>

        <div className="flex flex-col gap-12">
          {skillGroups.map((group, groupIndex) => (
            <div key={group.category} className="flex flex-col gap-6">
              <h3 className="text-text-muted font-mono text-sm tracking-[4px] border-l-2 border-accent pl-4">
                {group.category}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {group.skills.map((skill, index) => (
                  <motion.div
                    key={skill}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: (groupIndex * 0.1) + (index * 0.05) }}
                    whileHover={{ backgroundColor: '#ff0000', borderColor: '#ff0000' }}
                    className="bg-bg-base border border-accent px-8 py-4 rounded-sm text-center transition-all group cursor-default"
                  >
                    <span className="text-white font-mono text-lg group-hover:text-white transition-colors">
                      {skill}
                    </span>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
