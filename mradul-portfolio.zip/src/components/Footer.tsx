import React from 'react';
import { motion } from 'motion/react';
import { Github, Linkedin, FileText, ArrowUp, Mail } from 'lucide-react';

export const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-bg-elevated border-t border-border py-16 px-8 relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-accent to-transparent opacity-30" />
      
      <div className="max-w-[1400px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 items-center">
        {/* Logo & Copyright */}
        <div className="flex flex-col gap-4">
          <div className="font-display text-4xl text-accent tracking-widest">MM</div>
          <p className="text-text-muted font-mono text-xs tracking-widest uppercase">
            © 2026 MRADUL MANI MISHRA. <br />
            ALL RIGHTS RESERVED.
          </p>
        </div>

        {/* Social Links */}
        <div className="flex justify-center gap-8">
          <SocialLink href="https://github.com/mradulmanimishra" icon={Github} label="GITHUB" />
          <SocialLink href="https://linkedin.com/in/mradulmanimishra" icon={Linkedin} label="LINKEDIN" />
          <SocialLink href="#" icon={FileText} label="RESUME" />
          <SocialLink href="mailto:mradulmanimishra2022@gmail.com" icon={Mail} label="EMAIL" />
        </div>

        {/* Back to Top */}
        <div className="flex justify-end">
          <button 
            onClick={scrollToTop}
            className="group flex items-center gap-4 text-white font-display text-sm tracking-[4px] hover:text-accent transition-colors"
          >
            BACK TO TOP
            <div className="w-10 h-10 border border-border flex items-center justify-center group-hover:border-accent transition-colors">
              <ArrowUp size={16} className="group-hover:-translate-y-1 transition-transform" />
            </div>
          </button>
        </div>
      </div>

      {/* Bottom Tagline */}
      <div className="mt-16 text-center">
        <span className="text-text-muted font-display text-[10px] tracking-[8px] uppercase opacity-30">
          DESIGNED & DEVELOPED FOR THE FUTURE OF DATA
        </span>
      </div>
    </footer>
  );
};

const SocialLink = ({ href, icon: Icon, label }: { href: string; icon: any; label: string }) => (
  <motion.a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    whileHover={{ y: -5 }}
    className="flex flex-col items-center gap-2 group"
  >
    <div className="w-12 h-12 bg-bg-base border border-border flex items-center justify-center group-hover:border-accent transition-colors">
      <Icon size={20} className="text-white group-hover:text-accent transition-colors" />
    </div>
    <span className="text-text-muted font-mono text-[9px] tracking-widest uppercase group-hover:text-accent transition-colors">
      {label}
    </span>
  </motion.a>
);
