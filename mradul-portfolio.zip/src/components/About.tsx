import React from 'react';
import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';

const stats = [
  { value: '4', label: 'PATENTS FILED', sub: 'Innovations' },
  { value: '90%', label: 'ML ACCURACY', sub: 'Achieved' },
  { value: '1000+', label: 'SAMPLES', sub: 'Processed' },
  { value: '3', label: 'LIVE PROJECTS', sub: 'Deployed' },
];

export const About = () => {
  const { ref, inView } = useInView({
    threshold: 0.2,
    triggerOnce: true,
  });

  return (
    <section id="about" className="min-h-screen w-full flex items-center justify-center px-8 py-20 bg-[#050505]">
      <div ref={ref} className="max-w-[1400px] w-full grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
        
        {/* Left: Text */}
        <div className="lg:col-span-7">
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-white text-5xl md:text-7xl leading-[1.1] mb-8 font-display tracking-tight"
          >
            LET'S WORK TOGETHER <br />
            TO RECOGNIZE YOUR <br />
            <span className="text-accent">POTENTIAL</span> AND SHAPE <br />
            A FUTURE WHERE <br />
            YOUR <span className="text-accent">DATA</span> SHINES
          </motion.h2>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col gap-6"
          >
            <p className="text-text-secondary text-lg md:text-xl max-w-2xl leading-relaxed font-sans">
              I am a developer dedicated to building scalable AI solutions and intelligent IoT systems. From complex machine learning pipelines to patented IoT innovations, my work is driven by a passion for technical precision and creative problem-solving.
            </p>
            <div className="flex gap-4">
              <div className="h-[1px] w-12 bg-accent self-center" />
              <span className="text-accent font-mono text-xs tracking-[4px] uppercase">Mradul Mani Mishra</span>
            </div>
          </motion.div>
        </div>

        {/* Right: Image & Stats */}
        <div className="lg:col-span-5 flex flex-col gap-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 1 }}
            className="relative aspect-square w-full max-w-md mx-auto"
          >
            <div className="absolute inset-0 bg-accent/20 rounded-full blur-3xl -z-10 animate-pulse" />
            <img 
              src="https://lh3.googleusercontent.com/d/1xLQISzJHAoQRqUxxWSHS0FmKztle3kMb" 
              alt="Mradul Mani Mishra" 
              className="w-full h-full object-cover grayscale hover:grayscale-0 hover:scale-110 hover:shadow-[0_0_50px_rgba(255,0,0,0.4)] transition-all duration-700 border-4 border-accent rounded-full red-glow cursor-pointer"
              referrerPolicy="no-referrer"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-center"
          >
            <p className="text-accent font-display text-2xl tracking-[4px] uppercase font-bold">
              Data Scientist & ML Engineer
            </p>
          </motion.div>

          <div className="grid grid-cols-2 gap-4">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-bg-elevated border border-border p-6 flex flex-col items-center justify-center text-center group hover:border-accent transition-colors"
              >
                <span className="text-accent font-display text-5xl mb-1 group-hover:scale-110 transition-transform">
                  {stat.value}
                </span>
                <span className="text-white font-display text-sm tracking-widest mb-1">
                  {stat.label}
                </span>
                <span className="text-text-muted font-sans text-[10px] uppercase tracking-widest">
                  {stat.sub}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export const TechStackBanner = () => {
  const tech = [
    'Python', 'TensorFlow', 'Keras', 'Docker', 'PostgreSQL',
    'React', 'Tableau', 'AWS', 'Scikit-learn', 'NLTK'
  ];

  return (
    <div className="w-full bg-accent py-6 overflow-hidden relative">
      <div className="flex whitespace-nowrap animate-scroll">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="flex items-center gap-12 px-6">
            {tech.map((item) => (
              <React.Fragment key={item}>
                <span className="text-white font-display text-3xl tracking-widest uppercase">
                  {item}
                </span>
                <span className="text-white text-2xl">•</span>
              </React.Fragment>
            ))}
          </div>
        ))}
      </div>
      <style>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-scroll {
          animation: scroll 30s linear infinite;
        }
      `}</style>
    </div>
  );
};
