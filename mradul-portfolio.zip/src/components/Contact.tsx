import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, CheckCircle, Loader2 } from 'lucide-react';

export const Contact = () => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setStatus('success');
    setFormData({ name: '', email: '', message: '' });
    setTimeout(() => setStatus('idle'), 5000);
  };

  return (
    <section id="contact" className="min-h-screen w-full flex flex-col items-center justify-center px-8 py-20 bg-bg-base relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-[120px] -z-10" />

      <div className="max-w-[1400px] w-full grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div>
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-white text-6xl md:text-8xl leading-tight mb-8"
          >
            LET'S BUILD <br />
            <span className="text-accent">DATA-DRIVEN</span> SOLUTIONS <br />
            THAT SHAPE THE FUTURE
          </motion.h2>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-text-secondary text-xl font-sans max-w-xl mb-12 leading-relaxed"
          >
            Whether you're looking to deploy ML models, build automated data pipelines, or develop predictive systems — I bring technical expertise and innovation.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="bg-bg-elevated border border-border p-8 md:p-12 relative"
        >
          {status === 'success' ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <CheckCircle size={80} className="text-accent mb-6 animate-bounce" />
              <h3 className="text-white text-4xl mb-4">MESSAGE SENT!</h3>
              <p className="text-text-muted text-lg">Thank you for reaching out. I'll get back to you shortly.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="space-y-2">
                <label className="text-text-muted font-display text-sm tracking-widest uppercase">Name</label>
                <input 
                  required
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-bg-base border border-border px-6 py-4 text-white focus:border-accent outline-none transition-colors"
                  placeholder="YOUR NAME"
                />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted font-display text-sm tracking-widest uppercase">Email</label>
                <input 
                  required
                  type="email" 
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-bg-base border border-border px-6 py-4 text-white focus:border-accent outline-none transition-colors"
                  placeholder="YOUR EMAIL"
                />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted font-display text-sm tracking-widest uppercase">Message</label>
                <textarea 
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full bg-bg-base border border-border px-6 py-4 text-white focus:border-accent outline-none transition-colors resize-none"
                  placeholder="HOW CAN I HELP?"
                />
              </div>
              <button 
                disabled={status === 'loading'}
                className="w-full bg-accent text-white font-display text-2xl h-[70px] flex items-center justify-center gap-4 hover:translate-y-[-4px] transition-all red-glow disabled:opacity-50 disabled:translate-y-0"
              >
                {status === 'loading' ? (
                  <>SENDING... <Loader2 className="animate-spin" /></>
                ) : (
                  <>SEND MESSAGE <Send size={24} /></>
                )}
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
};
