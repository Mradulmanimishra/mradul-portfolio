import React from 'react';
import { motion } from 'motion/react';
import { Briefcase, Calendar, MapPin, CheckCircle2 } from 'lucide-react';

const experiences = [
  {
    company: 'Vitalis Ring',
    role: 'ML & Database Developer',
    period: 'Mar 2025 – Present',
    location: 'India',
    description: [
      'Engineered backend logic for real-time monitoring systems, utilizing Keras and TensorFlow to analyze high-frequency sensor data.',
      'Optimized database performance through normalization and statistical validation, ensuring 99.9% data integrity for critical health analytics.',
      'Developed predictive models that identify health anomalies with 92% precision, directly supporting core application features.'
    ],
    color: 'accent'
  },
  {
    company: 'BOOKOSE PLATFORM',
    role: 'Co-founded Marketplace',
    period: '2024 – 2025',
    location: 'India',
    description: [
      'Co-founded a community-driven marketplace, leading technical architecture to support rapid scaling to 500+ active users.',
      'Architected a scalable database system that managed 2,000+ unique book listings and reduced query latency by 35%.',
      'Implemented a habit-based recommendation engine that increased user engagement metrics by 40% within the first quarter.'
    ],
    color: 'white'
  }
];

export const Experience = () => {
  return (
    <section id="experience" className="w-full py-20 px-8 bg-bg-base">
      <div className="max-w-[1400px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="text-white text-6xl mb-16"
        >
          WORK EXPERIENCE
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative bg-bg-elevated border border-border p-10 aspect-square flex flex-col justify-between hover:border-accent transition-all duration-500"
            >
              <div className="space-y-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-white text-4xl font-display tracking-tight mb-2 group-hover:text-accent transition-colors">
                      {exp.company}
                    </h3>
                    <p className="text-accent font-sans text-xl italic">{exp.role}</p>
                  </div>
                  <Briefcase className="text-accent opacity-20 group-hover:opacity-100 transition-opacity" size={40} />
                </div>

                <div className="flex flex-wrap gap-6 text-text-muted font-mono text-sm uppercase tracking-widest">
                  <div className="flex items-center gap-2">
                    <Calendar size={16} className="text-accent" />
                    {exp.period}
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin size={16} className="text-accent" />
                    {exp.location}
                  </div>
                </div>

                <ul className="space-y-4 pt-4">
                  {exp.description.map((item, i) => (
                    <li key={i} className="text-text-secondary text-base leading-relaxed flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent flex-shrink-0 mt-1" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="absolute bottom-0 left-0 w-full h-1 bg-accent scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
