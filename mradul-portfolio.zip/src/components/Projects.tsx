import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink, Github, Search, Filter } from 'lucide-react';
import { projects, Project } from '../data/projects';
import { cn } from '../lib/utils';
import { trackEvent } from '../services/analytics';

export const Projects = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('All');

  const categories = ['All', 'AI', 'Machine Learning', 'Systems', 'Full Stack'];

  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesFilter = activeFilter === 'All' || p.category === activeFilter;
    return matchesSearch && matchesFilter;
  });

  const featuredProjects = projects.filter(p => p.featured);

  const handleProjectClick = (project: Project) => {
    setSelectedProject(project);
    trackEvent('project_view', { projectId: project.id, projectTitle: project.title });
  };

  return (
    <section id="projects" className="w-full py-20 px-8">
      <div className="max-w-[1400px] mx-auto">
        
        {/* Featured Section */}
        <div className="mb-32">
          <motion.h2 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="text-white text-6xl mb-16"
          >
            FEATURED INNOVATIONS
          </motion.h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {featuredProjects.map((project, index) => (
              <FeaturedCard key={project.id} project={project} index={index} onClick={() => handleProjectClick(project)} />
            ))}
          </div>
        </div>

        {/* Archive Section */}
        <div className="mb-16 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <motion.h2 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="text-white text-6xl"
          >
            PROJECT ARCHIVE
          </motion.h2>

          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted" size={18} />
              <input 
                type="text" 
                placeholder="SEARCH PROJECTS..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-bg-elevated border border-border pl-12 pr-6 py-3 text-white font-display tracking-widest focus:border-accent outline-none w-full md:w-64 transition-colors"
              />
            </div>
            {/* Filter */}
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 md:pb-0">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveFilter(cat)}
                  className={cn(
                    "px-4 py-2 font-display tracking-widest text-sm border transition-all whitespace-nowrap",
                    activeFilter === cat ? "bg-accent border-accent text-white" : "border-border text-text-muted hover:border-accent"
                  )}
                >
                  {cat.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} onClick={() => handleProjectClick(project)} />
          ))}
        </div>
      </div>

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
        )}
      </AnimatePresence>
    </section>
  );
};

const FeaturedCard: React.FC<{ project: Project; index: number; onClick: () => void }> = ({ project, index, onClick }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      onClick={onClick}
      className="group relative aspect-video bg-bg-elevated overflow-hidden cursor-pointer border border-border hover:border-accent transition-all duration-500"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/80 z-10 opacity-60 group-hover:opacity-40 transition-opacity" />
      <img 
        src={project.image} 
        alt={project.title} 
        className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
        referrerPolicy="no-referrer"
      />
      <div className="absolute bottom-8 left-8 z-20">
        <span className="text-accent font-mono text-sm mb-2 block tracking-[3px]">[{project.year}]</span>
        <h3 className="text-white text-4xl group-hover:text-accent transition-colors font-display tracking-tight mb-4">{project.title}</h3>
        <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
          <a 
            href={project.link} 
            onClick={(e) => e.stopPropagation()}
            className="p-2 bg-accent text-white rounded-sm hover:scale-110 transition-transform"
            title="Live Demo"
          >
            <ExternalLink size={18} />
          </a>
          <a 
            href={project.repo} 
            onClick={(e) => e.stopPropagation()}
            className="p-2 bg-white text-black rounded-sm hover:scale-110 transition-transform"
            title="View Code"
          >
            <Github size={18} />
          </a>
        </div>
      </div>
    </motion.div>
  );
};

const ProjectCard: React.FC<{ project: Project; index: number; onClick: () => void }> = ({ project, index, onClick }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      onClick={onClick}
      whileHover={{ y: -10 }}
      className="group relative bg-bg-elevated border border-border flex flex-col hover:border-accent transition-all duration-500 cursor-pointer overflow-hidden rounded-sm hover:shadow-[0_20px_50px_rgba(255,0,0,0.1)]"
    >
      <div className="aspect-video overflow-hidden border-b border-border relative">
        <img 
          src={project.image} 
          alt={project.title} 
          className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      <div className="p-8 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <span className="text-accent font-mono text-xs tracking-widest">[{project.year}]</span>
          <span className="text-text-muted font-display text-[10px] tracking-[2px] uppercase">{project.category}</span>
        </div>
        <h3 className="text-white text-2xl mb-4 group-hover:text-accent transition-colors font-display tracking-tight">{project.title}</h3>
        <p className="text-text-muted text-sm leading-relaxed mb-6 line-clamp-3">
          {project.description}
        </p>
        <div className="mt-auto flex items-center justify-between pt-6 border-t border-border/50">
          <div className="flex flex-wrap gap-2">
            {project.tags.slice(0, 2).map(tag => (
              <span key={tag} className="px-2 py-1 bg-bg-base border border-border text-white font-mono text-[9px] tracking-wider uppercase">
                {tag}
              </span>
            ))}
          </div>
          <div className="flex gap-3">
            <a 
              href={project.link} 
              onClick={(e) => e.stopPropagation()}
              className="text-text-muted hover:text-accent transition-colors"
              title="Live Demo"
            >
              <ExternalLink size={16} />
            </a>
            <a 
              href={project.repo} 
              onClick={(e) => e.stopPropagation()}
              className="text-text-muted hover:text-accent transition-colors"
              title="View Code"
            >
              <Github size={16} />
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const ProjectModal: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 bg-black/95 backdrop-blur-xl"
    >
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        className="bg-bg-elevated border border-accent w-full max-w-5xl max-h-full overflow-y-auto no-scrollbar relative"
      >
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 text-white hover:text-accent transition-colors z-50"
        >
          <X size={40} />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2">
          <div className="aspect-square lg:aspect-auto h-full overflow-hidden">
            <img 
              src={project.image} 
              alt={project.title} 
              className="w-full h-full object-cover grayscale"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="p-8 md:p-16">
            <div className="flex items-center gap-4 mb-6">
              <span className="text-accent font-mono text-sm tracking-widest">[{project.year}]</span>
              <span className="text-text-muted font-display text-sm tracking-widest uppercase">{project.category}</span>
            </div>
            
            <h2 className="text-white text-6xl mb-4">{project.title}</h2>
            <p className="text-text-secondary text-xl italic mb-8 font-sans">{project.subtitle}</p>
            
            <div className="space-y-8 mb-12">
              <div>
                <h4 className="text-accent font-display text-lg tracking-widest mb-4 uppercase">Overview</h4>
                <p className="text-text-muted text-lg leading-relaxed">{project.longDescription}</p>
              </div>

              <div>
                <h4 className="text-accent font-display text-lg tracking-widest mb-4 uppercase">Impact & Results</h4>
                <div className="space-y-6">
                  {project.impact.map((item, i) => {
                    const [label, content] = item.split(': ');
                    return (
                      <div key={i} className="flex flex-col gap-1">
                        <span className="text-accent font-display text-xs tracking-widest uppercase">{label}</span>
                        <p className="text-text-muted text-base leading-relaxed">{content}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <h4 className="text-accent font-display text-lg tracking-widest mb-4 uppercase">Technologies</h4>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-3 py-1 bg-bg-base border border-border text-white font-mono text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-6">
              <a 
                href={project.link}
                className="flex items-center justify-center gap-3 bg-accent text-white font-display text-xl px-8 py-4 hover:translate-y-[-4px] transition-all red-glow"
              >
                LIVE DEMO <ExternalLink size={20} />
              </a>
              <a 
                href={project.repo}
                className="flex items-center justify-center gap-3 border border-accent text-white font-display text-xl px-8 py-4 hover:bg-accent transition-all"
              >
                VIEW CODE <Github size={20} />
              </a>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
