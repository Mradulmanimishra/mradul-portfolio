import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar, ScrollProgress } from './components/Navigation';
import { Hero } from './components/Hero';
import { About, TechStackBanner } from './components/About';
import { Projects } from './components/Projects';
import { Patents } from './components/Patents';
import { Experience } from './components/Experience';
import { Skills } from './components/Skills';
import { Contact } from './components/Contact';
import { Testimonials } from './components/Testimonials';
import { Footer } from './components/Footer';
import { Chatbot } from './components/Chatbot';
import { trackEvent } from './services/analytics';

export default function App() {
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    trackEvent('page_view', { path: window.location.pathname });

    const moveCursor = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
    };

    const handleHover = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const isInteractive = target.closest('a, button, .group');
      setIsHovering(!!isInteractive);
    };

    window.addEventListener('mousemove', moveCursor);
    window.addEventListener('mouseover', handleHover);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      window.removeEventListener('mouseover', handleHover);
    };
  }, []);

  return (
    <div className="relative bg-bg-base selection:bg-accent selection:text-white">
      {/* Visual Enhancements */}
      <div className="noise-overlay" />
      <div 
        className={`custom-cursor hidden lg:block ${isHovering ? 'hover' : ''}`}
        style={{ 
          transform: `translate(${cursorPos.x - (isHovering ? 20 : 12)}px, ${cursorPos.y - (isHovering ? 20 : 12)}px)` 
        }}
      />

      {/* --- INTRO SPLASH SCREEN --- */}
      <AnimatePresence>
        {showIntro && (
          <motion.div
            key="intro-screen"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[99999] bg-black flex items-center justify-center overflow-hidden"
          >
            {/* Autoplaying Intro Video - Professional Grade Cinematic */}
            <video 
              autoPlay 
              muted 
              loop
              playsInline 
              preload="auto"
              crossOrigin="anonymous"
              onEnded={() => setShowIntro(false)}
              className="w-full h-full object-cover opacity-100 contrast-110 blur-[2px]"
            >
              {/* Primary: Cloudinary Hosted Video (High Reliability) */}
              <source src="https://res.cloudinary.com/do4alu53b/video/upload/SaveGram.App_AQOA0LR85k_2Wt30D4rHjZBTEqjF26GTTmNunGmKZdPN--KeOfvBXY74bNSXGUPeoAEguv_wXDrpt7iqikZZCGc2umA1Akg60-vR2Zs_online-video-cutter.com_2_epzc1m.mp4" type="video/mp4" />
              {/* Fallback 1: User's Google Drive Video */}
              <source src="https://drive.google.com/uc?id=1F71AIrgWJVM33Q5J4jgOXALxqSdHW4Sc&export=media" type="video/mp4" />
              {/* Fallback 2: Reliable Cinematic Tech Video */}
              <source src="https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-connection-lines-2316-large.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>

            {/* Red Overlay Effect */}
            <div className="absolute inset-0 bg-accent mix-blend-multiply opacity-20" />
            
            {/* Intro Text Overlay */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="absolute inset-0 flex flex-col items-center justify-center text-center z-10"
            >
              <h2 className="text-white text-6xl md:text-9xl font-display tracking-[12px] mb-4">MRADUL</h2>
              <div className="h-[2px] w-24 bg-accent mb-4" />
              <p className="text-accent font-mono text-sm tracking-[8px] uppercase">Innovating the Future</p>
            </motion.div>

            {/* Skip Button */}
            <button 
              onClick={() => setShowIntro(false)}
              className="absolute bottom-12 font-display text-sm text-white/50 tracking-[4px] uppercase hover:text-accent transition-colors z-10"
            >
              [ Skip Intro ]
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      
      <ScrollProgress />
      <Navbar />
      
      <main>
        <Hero />
        <About />
        <TechStackBanner />
        <Experience />
        <Projects />
        <Patents />
        <Testimonials />
        <Skills />
        <Contact />
      </main>

      <Footer />
      <Chatbot />
    </div>
  );
}
