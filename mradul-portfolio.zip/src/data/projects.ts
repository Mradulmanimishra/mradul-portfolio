export interface Project {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  longDescription: string;
  category: 'AI' | 'Machine Learning' | 'Systems' | 'Full Stack';
  tags: string[];
  year: string;
  link: string;
  repo: string;
  accuracy?: string;
  impact: string[];
  image: string;
  featured?: boolean;
}

export const projects: Project[] = [
  {
    id: 'msd-system',
    title: 'MSD SYSTEM',
    subtitle: 'ML Fault Detection Pipeline',
    description: 'The Mechanical System Diagnosis (MSD) system utilizes advanced signal processing and deep learning to identify anomalies in industrial machinery.',
    longDescription: 'The Mechanical System Diagnosis (MSD) system was developed to address the high costs of reactive maintenance in industrial settings. By leveraging advanced signal processing and deep learning, the system identifies anomalies in machinery before they lead to catastrophic failure.',
    category: 'Machine Learning',
    tags: ['Python', 'Keras', 'TensorFlow', 'Signal Processing'],
    year: '2024',
    link: 'https://demo.example.com/msd',
    repo: 'https://github.com/mradul/msd-system',
    accuracy: '90%',
    impact: [
      'Problem: High operational costs due to unexpected industrial machinery failure.',
      'Action: Developed a deep learning pipeline using Keras/TensorFlow to analyze vibration and acoustic sensor data.',
      'Result: Achieved 90% detection accuracy, reducing estimated downtime by 25%.'
    ],
    image: 'https://picsum.photos/seed/engine/800/600?grayscale',
    featured: true
  },
  {
    id: 'insurance-automation',
    title: 'INSURANCE CLAIMS AUTOMATION',
    subtitle: 'NLP pipeline reducing manual errors',
    description: 'Automated extraction and validation of insurance claims using NLP and Transformer-based models.',
    longDescription: 'This project addressed the bottleneck of manual insurance claim processing. I built an end-to-end NLP pipeline that extracts key information from unstructured documents and validates it against policy rules in real-time.',
    category: 'AI',
    tags: ['NLTK', 'Spacy', 'Python', 'Automation', 'Transformers'],
    year: '2024',
    link: 'https://demo.example.com/insurance',
    repo: 'https://github.com/mradul/insurance-automation',
    impact: [
      'Problem: Manual data entry for insurance claims was slow and prone to 15%+ error rates.',
      'Action: Built a Transformer-based NLP pipeline for automated document classification and data extraction.',
      'Result: Reduced manual entry errors by 60% and decreased processing time from 3 days to 4 hours.'
    ],
    image: 'https://picsum.photos/seed/document/800/600?grayscale',
    featured: true
  },
  {
    id: 'real-estate-analytics',
    title: 'REAL ESTATE ANALYTICS',
    subtitle: 'Property pricing dashboard',
    description: 'Interactive dashboard providing predictive insights into property pricing across India.',
    longDescription: 'Real estate investors lacked a centralized tool for predictive market analysis. I developed a comprehensive platform that combines historical market trends with geographical data to provide accurate pricing forecasts.',
    category: 'Systems',
    tags: ['React', 'Flask', 'PostgreSQL', 'Data Viz'],
    year: '2024',
    link: 'https://demo.example.com/realestate',
    repo: 'https://github.com/mradul/real-estate-analytics',
    impact: [
      'Problem: Lack of transparent, data-driven property pricing insights for the Indian market.',
      'Action: Developed a Flask-based predictive model and a React dashboard to visualize 1M+ property records.',
      'Result: Provided pricing predictions with a 92% R-squared value and integrated real-time market data.'
    ],
    image: 'https://picsum.photos/seed/city/800/600?grayscale'
  },
  {
    id: 'bookose',
    title: 'BOOKOSE PLATFORM',
    subtitle: 'Co-founded Marketplace',
    description: 'Bookose is a community-driven marketplace for second-hand books with a custom recommendation engine.',
    longDescription: 'As a co-founder, I addressed the lack of a secure, community-focused platform for second-hand book exchange. I led the technical development, focusing on scalability and user engagement through personalized recommendations.',
    category: 'Full Stack',
    tags: ['SQL', 'NoSQL', 'Python', 'Scalable DB'],
    year: '2025',
    link: 'https://bookose.com',
    repo: 'https://github.com/mradul/bookose',
    impact: [
      'Problem: Difficulty in finding and exchanging niche second-hand books within local communities.',
      'Action: Architected a scalable full-stack platform and developed a habit-based recommendation engine.',
      'Result: Successfully onboarded 500+ active users and managed 2,000+ unique book listings.'
    ],
    image: 'https://picsum.photos/seed/library/800/600?grayscale'
  }
];
