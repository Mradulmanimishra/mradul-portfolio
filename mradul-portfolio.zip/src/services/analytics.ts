export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
  // In a real app, this would send data to Mixpanel, Google Analytics, or a custom backend.
  // For this portfolio, we'll log it to the console with a professional prefix.
  console.log(`[ANALYTICS] ${eventName}`, properties || {});
  
  // We could also store it in localStorage for a simple "session" view
  const logs = JSON.parse(localStorage.getItem('portfolio_analytics') || '[]');
  logs.push({
    event: eventName,
    timestamp: new Date().toISOString(),
    ...properties
  });
  localStorage.setItem('portfolio_analytics', JSON.stringify(logs.slice(-50))); // Keep last 50 events
};

export const getAnalytics = () => {
  return JSON.parse(localStorage.getItem('portfolio_analytics') || '[]');
};
